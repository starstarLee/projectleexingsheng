<?php

// Connect to MySQL
$link = mysqli_connect('localhost', 'root', '');
if (!$link) 
{
    die('Could not connect: ' . mysqli_connect_error());
}

// Make my_db the current database
$db_selected = mysqli_select_db($link, 'dblogin');
if (!$db_selected) 
{
  // If we couldn't, then it either doesn't exist, or we can't see it.
  $sql = 'CREATE DATABASE dblogin;'; 

    if (mysqli_query($link, $sql)) 
    {       
        echo "Database dbLogin created successfully<br />";
        $db_selected = mysqli_select_db($link, 'dblogin');
    } 
    else 
    {
        die("Error creating database: " . mysqli_error($link) . "<br />");
    }

    $sql = 'CREATE TABLE IF NOT EXISTS userdata(
        USERNAME varchar(100),
        PASSWORD_HASH CHAR(40) not null,
        PHONE varchar(10) not null,
        code varchar(100) null,
        email varchar(100) not null unique,
        PRIMARY KEY (USERNAME));
        ';

    if (mysqli_query($link, $sql)) 
    {       
        echo "Table created successfully<br />";
    } 
    else 
    {
        die("Error creating table: " . mysqli_error($link) . "<br />");
    }    
}
?>