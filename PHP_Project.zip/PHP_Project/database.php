<?php
include("dbCon.php");
  $sql = 'CREATE TABLE IF NOT EXISTS user(
        NAME varchar(100),
        Email varchar(100) not null,
        Age int not null,
		Birthdate date not null,
		Favourite_Food varchar(100) not null,
		Gender varchar(100) not null,
		Eye_color varchar(10) not null,
		Bio varchar(100) not null,
		File varchar(100) not null,
		URL varchar(100) not null,
		colour varchar(10) not null,
		USERNAME varchar(100),
		PRIMARY KEY (NAME),
		FOREIGN KEY (USERNAME)REFERENCES userdata (USERNAME)
		
        );
		 ';
	if (mysqli_query($link, $sql)) 
    {       
        echo "Table created successfully<br />";
    } 
    else 
    {
        die("Error creating table: " . mysqli_error($link) . "<br />");
    }    

?>