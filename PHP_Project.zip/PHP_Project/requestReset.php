<head>  
<link rel="stylesheet" href="css.css">
</head>
<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'dbCon.php';

if(isset($_POST["submit"])){
    
    $username = mysqli_real_escape_string($link, $_POST['username']);
    $result = mysqli_query($link, "SELECT USERNAME, PHONE, email from userdata WHERE USERNAME='$username'");

    if(!$result) //error executing query
    {
        echo "<p id=success>Error: ".mysqli_error($link)."<br /></p>";
    }
   else if(mysqli_num_rows($result)==0) //if the username not exist
    {
        echo "<p id=success>Invalid username</p>";
    }
    else
    {
        $row = mysqli_fetch_assoc($result);
        if($_POST['phone'] == $row['PHONE'] && $_POST['email'] == $row['email']) //if all credentials correct, send email
        {
            $emailTo = $_POST["email"];

            $code = uniqid(true);
            $query = mysqli_query($link, "UPDATE userdata SET code = '$code' WHERE username='$username'");
            if(!$query){
                echo "<p id=success>".mysqli_error($link)."</p>";
                exit("Error");
            }

        //Instantiation and passing `true` enables exceptions
            $mail = new PHPMailer(true);

            try {
                //Server settings
                $mail->isSMTP();                                            //Send using SMTP
                $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
                $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
                $mail->Username   = 'i18015852@student.newinti.edu.my';     //SMTP username
                $mail->Password   = 'iu000616060619';                       //SMTP password
                $mail->SMTPSecure = 'tls';         //Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
                $mail->Port       = 587;                                    //TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above
                
                //Recipients
                $mail->setFrom('i18015852@student.newinti.edu.my'); 
                $mail->addAddress("$emailTo");     //Add a recipient
                $mail->addReplyTo('no-reply@gmail.com', 'no-reply');

                //Content
                $url = "http://".$_SERVER["HTTP_HOST"]. dirname($_SERVER["PHP_SELF"]).
                "/resetPassword.php?code=$code";
                $mail->isHTML(true);                                  //Set email format to HTML
                $mail->Subject = 'Password reset link.';
                $mail->Body    = "<h1>You requested a password reset. </h1>Click 
                <a href='$url'>this link</a> to do so";
                $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

                $mail->send();
                echo '<p id=success>Reset password link has been sent to your email.</p>';
            } catch (Exception $e) {
                echo "<p id=success>Message could not be sent. Mailer Error: {$mail->ErrorInfo}</p>";
            }
            exit();
        }
        echo "<p id=success>Wrong phone number or email provided for reseting password</p>";
    }

    
}


?>
<p id=reee>Reset Your Password</p> 
<p id=success>Please enter your username, phone and email to retrive password.</p>
<form method="POST">
    <label>Username:</label> <input type="text" name="username" id="username" placeholder="Username" ><br />
    <label>Phone:</label> <input type="text" name="phone" placeholder="Phone" id="phone" ><br />
    <label>Email:</label> <input type="text" name="email" placeholder="Email"id="email" ><br />
    </br>
    <input type="submit" name="submit" id="submit" value="Reset Email"><br><br>
    <input type="button" name="back" value="Back" id="back" onclick="window.location='loginForm.php'"/>
</form>