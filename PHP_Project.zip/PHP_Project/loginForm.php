<html>
<body>
<head> 
<link rel="stylesheet" href="css.css">
 </head>

<?php

function loginValidation($link, $username, $password_hash)
{
	$username=mysqli_real_escape_string($link, $username);
	$password_hash=mysqli_real_escape_string($link, $password_hash);

	$result = mysqli_query($link, "SELECT userdata.password_hash FROM userdata WHERE username = '$username'");
	$row = mysqli_fetch_assoc($result);
	if($row === null)
	{
		return false;
	}
	else
	{
		return ($row['password_hash'] === $password_hash);
	}
	
}

include("dbCon.php");
session_start();

if(!isset($_SESSION['check'])) //in first login, session variable is not set so set ['check'] to false
{
	$_SESSION['check'] = false;
}

if(isset($_SESSION['error'])) //if there is error in form
{
	echo $_SESSION['error'];
	unset($_SESSION['error']);
}

if(isset($_POST['logout'])) //if user logout
{
	$password_hash = md5($_POST['password']); //encrypt the password entered by the user
	$_SESSION = array();
	session_destroy(); //$_SESSION become null
	if(isset($_COOKIE['username']) && isset($_COOKIE['password']))
	{
		setcookie('username', $_POST['username'], time()-3600);
		setcookie('password', $_POST['password'], time()-3600);
	}
	
	header("Location:".$_SERVER['PHP_SELF']); //perform Post/Redirect/Get
}
else if(isset($_POST['submit'])) //if user log in through form
{
	
	$password_hash = md5($_POST['password']); //encrypt the password entered by the user
	if($_SESSION['check'] =loginValidation($link, $_POST['username'], $password_hash))
	{
		$_SESSION['username']=$_POST['username'];
		if(isset($_POST['rememberMe']))
		{			
			setcookie('username', $_POST['username'], time()+86400);
			setcookie('password', $_POST['password'], time()+86400);
		}
	}
	else
	{
		$_SESSION['error'] = "<p id=invalid>Invalid username or password <br /><br /></p>";
	}	
	
	header("Location:".$_SERVER['PHP_SELF']); //perform Post/Redirect/Get
}
else if(isset($_COOKIE['username']) && isset($_COOKIE['password'])) //if user log in through cookie
{
	$username=$_COOKIE['username'];
	$password_hash = md5($_COOKIE['password']);
	if($_SESSION['check'] = loginValidation($link, $username, $password_hash))
	{
		$_SESSION['username'] = $_COOKIE['username'];
	}
}


if ($_SESSION != null && $_SESSION['check']) //session is on, meaning the user log in
{ 
?>

	<style>
	</style>
	<form method="POST" action="" id="form2">
		<?php
			echo '<script> var name = "Hello, '.$_SESSION['username'].'";
			alert(name);</script>';
			
		?>
			<input type="submit" name="logout" value="Log Out" id="logout"/><br><br>
			
		
				<h1>Homepage</h1><br>

					<a href= "insertForm.php">Add Data</a><br><br>
			
					<a href= "display.php" id="a2">Display Data</a>
			
		
	</form>
	
<?php
}
else //either session not set or $_SESSION['check'] is false
{
?>	
	<form action="" method="POST">
		<label>Username:</label> <input type="text" name="username" id="username" required /><br />
		<label>Password:</label> <input type="password" name="password" id="password_hash"required /><br /><br>
		<input type="submit" name="submit" id="submit" /><br><br>
		<input type="button" name="Register" id="register" value="Register" onclick= "window.location= 'registration.php'" />
		<input type="button" name="forgetPassword" value="Forget password" id="forget" onclick="window.location='requestReset.php'"/><br>
		<input type="checkbox" name="rememberMe"/>
		<label for="rememberMe" id="remember" >Remember Me </label><br>
	</form>
<?php
}
?>

</body>
</html>