<td><input type="submit" name="back" value="Back" id="back" onclick ="window.location.href = 'loginForm.php'"></td></tr>
<head>
<link rel="stylesheet" href="css.css">
</head>
<?php
session_start();
if(!isset($_SESSION) || !$_SESSION['check']) //if session not set or ['check'] is false, redirect back to login page
{
  header("Location: loginForm.php");
}
include("dbCon.php"); 


echo '<form id="form3"action="'.$_SERVER['PHP_SELF'].'" method="post"><table border="1"><br><tr><td><input type="text" name="searchquery" ></td>
<td><input type="submit" name="search" value="Search"></tr></table></form>';

if(isset($_POST['search'])){
	$search = mysqli_real_escape_string($link, $_POST['searchquery']);
	$query = mysqli_query($link, "SELECT * FROM user WHERE NAME LIKE '%$search%'");
	
	if(mysqli_num_rows($query)!=0){
		echo '<table border="1" id="record"><tr>
			<th>Name</th> <th>Email</th> <th>Age</th> <th>Birthdate</th> <th>Favourite_Food</th>
			<th>Gender</th> <th>Eye_color</th> <th>Bio</th> <th>File</th> <th>URL</th> <th>Colour</th> <th>Username</th>
			<th></th><th></th>
		</tr>';
		while($row = mysqli_fetch_array($query)){
			echo '<tr>
				<td>'.$row['NAME'].'</td>
				<td>'.$row['Email'].'</td>
				<td>'.$row['Age'].'</td>
				<td>'.$row['Birthdate'].'</td>
				<td>'.$row['Favourite_Food'].'</td>
				<td>'.$row['Gender'].'</td>
				<td>'.$row['Eye_color'].'</td>
				<td>'.$row['Bio'].'</td>
				<td>'.$row['File'].'</td>
				<td>'.$row['URL'].'</td>
				<td>'.$row['colour'].'</td>
				<td>'.$row['USERNAME'].'</td>
				<td><input type="button" onclick="window.location = \'EF.php?NAME='.$row['NAME'].'\'" value="Edit"></td>
				<td><input type="button" onclick="window.location = \'Delete(new).php?NAME='.$row['NAME'].'\'" value="Delete"></td>
				</tr>';
		}
		echo '</table>';
		exit();
	} else {
		echo '<h2>No result</h2>';
		exit();
	}
}

$query = mysqli_query($link, "SELECT * FROM user");

echo '<table border="1" id="record"><tr>
	<th>Name</th> <th>Email</th> <th>Age</th> <th>Birthdate</th> <th>Favourite_Food</th>
			<th>Gender</th> <th>Eye_color</th> <th>Bio</th> <th>File</th> <th>URL</th> <th>Colour</th> <th>Username</th>
			<th></th><th></th>
	</tr>';
while($row = mysqli_fetch_array($query)){
	echo '<tr>
		<td>'.$row['NAME'].'</td>
				<td>'.$row['Email'].'</td>
				<td>'.$row['Age'].'</td>
				<td>'.$row['Birthdate'].'</td>
				<td>'.$row['Favourite_Food'].'</td>
				<td>'.$row['Gender'].'</td>
				<td>'.$row['Eye_color'].'</td>
				<td>'.$row['Bio'].'</td>
				<td>'.$row['File'].'</td>
				<td>'.$row['URL'].'</td>
				<td>'.$row['colour'].'</td>
				<td>'.$row['USERNAME'].'</td>
		<td><input type="button" onclick="window.location = \'editForm.php?NAME='.$row['NAME'].'\'" value="Edit"></td>
		<td><input type="button" onclick="window.location = \'delete.php?NAME='.$row['NAME'].'\'" value="Delete"></td>
		</tr>';
}
echo '</table>';

?>
