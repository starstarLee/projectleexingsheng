<head>  
<link rel="stylesheet" href="css.css">
</head>
<?php
include('dbCon.php'); 
session_start();

if(!isset($_SESSION) || !$_SESSION['check']) //if session not set or ['check'] is false, redirect back to login page
{
  header("Location: loginForm.php");
}

if(isset($_POST['delete'])){
	$delete = mysqli_query($link, "DELETE FROM user WHERE NAME ='{$_POST['name']}'");
	
	if($delete){
		echo '<script>alert("Deleted Successfully")</script><br><a href="Display.php">Back to Homepage</a>';
		exit();
	} else {
		echo 'Failed to delete record because '.mysqli_error($link);
	}
}
?>
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
<input type="hidden" value="<?php echo $_REQUEST['NAME']; ?>" name="name">
<table>
<tr>
	<td><label>Do you want to delete the selected file?</label></td><br>
</tr>
<tr>
    <td><input type="submit" name="delete" value="Yes" id="yes">
	<input type="button" value="Cancel"id="cancel" onclick="window.location ='Display.php'"></td>
</tr>
</table>
</form>

