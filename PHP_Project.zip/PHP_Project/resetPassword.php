<?php
include ('dbCon.php');

if(!isset($_GET["code"])){
    exit("Can't find page");
}

$code =$_GET["code"];

$getEmailQuery = mysqli_query($link, "SELECT email FROM userdata 
    WHERE code ='$code'");
if(mysqli_num_rows($getEmailQuery)== 0){
    exit("Can't find page");
}

if(isset($_POST["password"])){
    $pw = $_POST["password"];
    $pw = md5($pw);

    $row = mysqli_fetch_array($getEmailQuery);
        $email = $row["email"];

        $query = mysqli_query($link, "UPDATE userdata SET PASSWORD_HASH='$pw' WHERE code='$code'");

         if($query){
             $query = mysqli_query($link, "UPDATE userdata SET code=null WHERE code='$code'");
             echo "Password updated.";
             ?><a href= 'loginForm.php'>Back to login</a><?php
             die();
         }else{
            exit("Something went wrong!");
         }
}

?>
<h1>Reset Password</h1>
<p>Please enter your password.</p>
<form method="POST">
    Password: <input type="password" name="password" placeholder="New password">
    </br>
    <input type="submit" name="submit" value="Update password">
</form>