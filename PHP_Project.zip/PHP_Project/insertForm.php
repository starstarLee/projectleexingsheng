<html>
<body>
<head>
<link rel="stylesheet" href="css.css">
  <script src="http://ajax.googleapis.com/ajax/libs/jquery/2.1.0/jquery.min.js">
  </script>
  <script type="text/javascript">
$(document).ready(function () {
    $('#submit').click(function() {
      checked = $("input[type=checkbox]:checked").length;

      if(!checked) {
        alert("You must check at least one checkbox.");
        return false;
      }

    });
});
</script>
<script type="text/javascript">
$(document).ready(function () {
    $('#submit').click(function() {
      checked = $("input[type=radio]:checked").length;

      if(!checked) {
        alert("You must check at least one radio.");
        return false;
      }

    });
});
</script>
<?php
session_start();

if(!isset($_SESSION) || !$_SESSION['check']) //if session not set or ['check'] is false, redirect back to login page
{
  header("Location: loginForm.php");
}

include("database.php");


if(isset($_POST["submit"])){

		
	$name=mysqli_real_escape_string($link, $_POST['name']);
	$email=mysqli_real_escape_string($link, $_POST['email']);
	$age=mysqli_real_escape_string($link, $_POST['age']);
	$birthdate=mysqli_real_escape_string($link, $_POST['birthdate']);
	$favourite_food=mysqli_real_escape_string($link, implode(',',$_POST['favourite_food']));
	$gender=mysqli_real_escape_string($link, $_POST['gender']);
	$eyecolour=mysqli_real_escape_string($link, implode(',',$_POST['eyeColor']));
	$bio=mysqli_real_escape_string($link, $_POST['bio']);
	$file=mysqli_real_escape_string($link, $_POST['file']);
	$url=mysqli_real_escape_string($link, $_POST['url']);
	$color=mysqli_real_escape_string($link, $_POST['color']);
	$username=mysqli_real_escape_string($link, $_SESSION['username']);
	$insert=mysqli_query($link, "INSERT INTO user VALUES('$name', '$email', '$age','$birthdate','$favourite_food','$gender','$eyecolour','$bio','$file','$url','$color','$username');");
	if($insert)
	{
		echo "<p id=success>Data inserted into database succesfully </p>";
		echo "<p id=success>NAME: $name </p>";
		echo "<p id=success>Email: $email </p>";
		echo "<p id=success>Age: $age </p>";
		echo "<p id=success>Birthdate: $birthdate </p>";
		echo "<p id=success>Favourite_Food: $favourite_food </p>";
		echo "<p id=success>gender: $gender </p>";
		echo "<p id=success>Eye_colour: $eyecolour </p>";
		echo "<p id=success>Bio: $bio </p>";
		echo "<p id=success>File: $file </p>";
		echo "<p id=success>URL: $url </p>";
		echo "<p id=success>colour: $color </p>";
		echo "<p id=success>username: $username </p>";
		
		
	}
	else
	{
		echo "<p id=success>Data insertion fail because ".mysqli_error($link)."<br /><br /></p>";
	}
}
?>
<form action="" method="post">
  <div>
  <label for ="name"> Name </label> 
  <input type="text"  name="name" id="username" required>  <br /> <br />
  </div>
   <div>
  <label for="email"> Email</label> 
  <input type="email" name="email" id="email" required>  <br /> <br />
  </div>
  <div>
  <label for="age"> Age</label>
  <input type="number" name="age" id="age" required min="1" max="200" step="1" > <br /> <br />
  </div>
   <div>
  <label for="birthdate"> Birthdate </label>
  <input type="date" name="birthdate" id="date" required min="2019-06-10" > <br /> <br />
  </div>
  <div>
  <label>Favourite Food</label>
  <div>
  <label for="favourite_food" > Banana </label>
  <input type="checkbox" name="favourite_food[]" id="banana" value="banana"  > 

  </div>
 </div>
 
 <div>
 <div>
 <label for="favourite_food"> Apple </label>
 <input type="checkbox" name="favourite_food[]" id="apple" value="apple"  >
 <br /> <br />
  
  
  </div>
 <label>Gender</label>
 <div>
 <label for="male"> Male</label>
 <input type="radio" name="gender" id="male" value="male">
 </div>
  <div>
 <label for="female"> Female</label>
 <input type="radio" name="gender" id="female" value="female"> <br /> <br />
 </div>
 </div>
 <div>
 <label for="eyeColor">Eye colour</label> 
 <select name="eyeColor[]" id="eyeColor" multiple required>   
 <option value="Green">Green</option> 
 <option value="Red">Red</option> 
 </select>
 </div>
  

 <br /> <label for="bio">Bio </label>
  <textarea id="bio" name="bio"> </textarea> <br /> <br />
 
  <label for="file">File</label>
  <input id="file" required type="file" name="file"> <br /> <br />
  </div>
  <div>
  
  <div>
  <label for="url">URL</label>
  <input type="url" name="url" id="url" required> <br /> <br />
  </div>
  <div>
  </div>
  <label for="colour"> Colour</label>
  <input type="color" name="color" id="colour" required> <br /> <br />
    <div>
  


  </div>
 

   <button type="submit" name="submit" id="submit"> Submit </button> <br><br>
   <button type="reset" name="reset" id="reset"> Reset </button> 
   <button type="submit" name="back" id="back" onclick="window.location = 'loginForm.php'"> Back </button>
   

</form>
</body>
</html>