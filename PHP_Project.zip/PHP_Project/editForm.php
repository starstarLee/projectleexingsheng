<html>
<body>
<head> 
<link rel="stylesheet" href="css.css">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/2.1.0/jquery.min.js">
  </script>
 <script type="text/javascript">
$(document).ready(function () {
    $('#submit').click(function() {
      checked = $("input[type=checkbox]:checked").length;

      if(!checked) {
        alert("You must check at least one checkbox.");
        return false;
      }

    });
});

</script>

<script type="text/javascript">
$(document).ready(function () {
    $('#submit').click(function() {
      checked = $("input[type=radio]:checked").length;

      if(!checked) {
        alert("You must check at least one radio.");
        return false;
      }

    });
});
</script>

</head>

<?php // table - user 
session_start();
if(!isset($_SESSION) || !$_SESSION['check']) //if session not set or ['check'] is false, redirect back to login page
{
  header("Location: loginForm.php");
}
include ("dbCon.php");



?>

<?php

if(isset($_POST['submit']))
{	
	$name =mysqli_real_escape_string($link, $_POST['name']);
	$email=mysqli_real_escape_string($link, $_POST['email']);
	$age=mysqli_real_escape_string($link, $_POST['age']);
	$birthdate=mysqli_real_escape_string($link, $_POST['birthdate']);
	$favourite_food=mysqli_real_escape_string($link, implode(',',$_POST['favourite_food']));
	$gender=mysqli_real_escape_string($link,$_POST['gender']);
	$eyecolour=mysqli_real_escape_string($link, $_POST['eyeColor']);
	$bio=mysqli_real_escape_string($link, $_POST['bio']);
	$file=mysqli_real_escape_string($link, $_POST['file']);
	$url=mysqli_real_escape_string($link, $_POST['url']);
	$color=mysqli_real_escape_string($link, $_POST['color']);
	$username=mysqli_real_escape_string($link, $_SESSION['username']);
	$insert=mysqli_query($link, "UPDATE user SET NAME ='$name', Email = '$email', Age='$age', Birthdate = '$birthdate', Favourite_Food='$favourite_food', Gender='$gender', Eye_color='$eyecolour', Bio ='$bio'
	, File ='$file' , URL = '$url', colour='$color' WHERE NAME = '{$_POST['name']}'");

	if($insert)
	{
		echo '<p id=success>Succesfully edit record.</p>';
	}
	else
	{
		echo '<p id=success>Failed to edit record because '.mysqli_error($link).'</p>';
	}	
}

	$query = mysqli_query($link, "SELECT * FROM user WHERE NAME ='{$_REQUEST['NAME']}' ");
	while($row = mysqli_fetch_array($query)){
	$name= $row['NAME'];
	$email = $row['Email'];
	$age = $row['Age'];
	$bd = $row['Birthdate'];
	$ff = $row['Favourite_Food'];
	$g = $row['Gender'];
	$ec = $row['Eye_color'];
	$bio = $row['Bio'];
	$file = $row['File'];
	$url = $row['URL'];
	$color = $row['colour'];
	
	}
?>



<form action='' method='post' id='form4'>
<table border="1" id="table1">
	<tr>
		<td colspan = 2> <input type='button' name='back' value='back' id='back' onclick="window.location='Display.php'"> </td>
	<tr>
		<td colspan = 2 style="font-size:large; font-weight:bold" ><label> User Data </label></td>
	<tr>
		<td><label>Name</label></td>
		<td> <input type='text' name='name' id='username' value= "<?php  echo $name;?>" required> </td>
	</tr>
	<tr>
		<td><label>Email</label></td>
		<td> <input type='text' name='email' id='email' value= "<?php echo $email;?>"  required> </td>
	</tr>
	<tr>
		<td><label>Age</label></td>
		<td> <input type='text' name='age' id='age' value="<?php echo $age;?>" required min="1" max="200" step="1"> </td>
	</tr>
	<tr>
		<td><label>Birthdate</label></td>
		<td> <input type='text' name='birthdate'id="date" value="<?php echo $bd; ?>" required min="2019-06-10"> </td>
	</tr>
	<tr>
		<td><label>Favourite_Food</label></td>
		<td> 
		<label for="favourite_food"> Banana </label>
		<input type="checkbox" name="favourite_food[]" id="banana" value = "banana" <?php echo ($ff =='banana' || $ff == 'banana,apple')?"checked":"" ;?>> 
		<label for="favourite_food"> Apple </label>
		<input type="checkbox" name="favourite_food[]" id="apple" value = "apple" <?php echo ($ff =='apple' || $ff == 'banana,apple')?"checked":"" ;?> > 
		</td>
		
	</tr>
  
	<tr>
		<td><label>Gender</label></td>
		<td> 
		<input type="radio" name="gender" id="male" value="male" <?php echo ($g =='male')?"checked":"" ;?>>
		<label for="male"> Male</label>
		<input type="radio" name="gender" id="female" value="female"<?php echo ($g =='female')?"checked":"" ;?>> 
		<label for="female"> Female</label>
		</td>
	</tr>
	<tr>
		
		<td><label>Eye Color</label></td>
		<td><label for="eyeColor">Eye colour</label>
	<select name="eyeColor" id="eyeColor" multiple required >  
		<option value="Green" <?php echo ($ec == 'Green' || $ec == 'Green,Red')?'selected="selected"' :'';?>>Green</option>
		<option value="Red" <?php echo ($ec == 'Red' || $ec == 'Green,Red')?'selected="selected"' :'';?>>Red</option>
	    
		</select>
		</td>
	</tr>
	<tr>
		<td><label>Bio</label></td>
		<td> 
		<textarea id="bio" name="bio">
		<?php $bio = mysqli_query($link ,"SELECT Bio from user WHERE NAME = '{$_REQUEST['NAME']}'");
		while($biorow = mysqli_fetch_array($bio)){
			echo $biorow['Bio'];}
		?>
		</textarea>
		</td>
	</tr>
	<tr>
		<td><label>File</label></td>
		<td> 
		<input id="file" type="file" name="file" required> <br /> <br /> 
		 		
			 <?php 
			 
			 echo $file; 
			
			?>
		
		</td>
	</tr>
	<tr>
		<td><label>URL</label></td>
		<td> 
		<input type="url" name="url" id="url" value="<?php $url = mysqli_query($link ,"SELECT url FROM user WHERE NAME = '{$_REQUEST['NAME']}'");
		while($urlrow = mysqli_fetch_array($url)){
			echo $urlrow['url'];}
		?>" required></td>
	</tr>
	<tr>
		<td><label>Colour</label></td>
		<td> 
		<input type="color" name="color" id="colour" value = "<?php $colour = mysqli_query($link ,"SELECT colour FROM user WHERE NAME = '{$_REQUEST['NAME']}'"); 
		while($colrow = mysqli_fetch_array($colour)){
			echo $colrow['colour'];} ?>" required > 
		<br /> <br />
		</td>
	</tr>
		
	
	<tr>
		<td colspan = 2><input type = 'submit' name='submit' value='Submit' id='submit'></td>
	</tr>	
</table>
</form>



</body>
</html>