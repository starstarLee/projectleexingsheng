<html>
<body>
<head>  
<link rel="stylesheet" href="css.css">
</head>

<?php
include("dbCon.php");
if(isset($_POST["submit"]))
{
	$username=mysqli_real_escape_string($link, $_POST['username']);
	$password = $_POST['password']; //store unhashed password
	$password_hash=mysqli_real_escape_string($link, md5($_POST['password'])); //md5 hashing
	$phone=mysqli_real_escape_string($link, $_POST['phone']);
	$email=mysqli_real_escape_string($link, $_POST['email']);

	//$checkDuplicate = mysqli_query($link, "SELECT username FROM userdata");

	/*while($row=mysqli_fetch_array($checkDuplicate))
	{
		if($row['username'] == $username) //duplicate username
		{
			echo "Duplicate username detected, please choose another username<br />";
			break;
		}
	}*/

	$insert=mysqli_query($link, "INSERT INTO userdata VALUES('$username', '$password_hash', '$phone', null, '$email');");

	if($insert)
	{
		echo "<p id=success>Data inserted into database succesfully </p>";
		echo "<p id=success>Username: $username </p>";
		echo "<p id=success>Password: $password </p>";
		echo "<p id=success>Phone: $phone </p>";
		echo "<p id=success>Email: $email </p>";
	}
	else
	{
		echo "<p id=success>Data insertion fail because ".mysqli_error($link)."</p><br /><br />";
	}
 
}


?>

<form action="" method="POST">
	<label>Username:</label> <input type="text" name="username" id="username" required /><br />
	<label>Password:</label> <input type="password" name="password" id="password_hash" required /><br />
	<label>Phone:</label> <input type="tel" name="phone" id="phone" required/><br />
	<label>Email:</label> <input type="email" name="email" id="email" required/><br /><br>
	<input type="submit" name="submit" id="submit" /><br><br>
	<input type="submit" name="back" value="Back" id="back" onclick="window.location = 'loginForm.php'" /><br />
</form>

</html>
</body>